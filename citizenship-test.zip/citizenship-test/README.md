# Citizenship Test

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/GerardoCodesCardoso123/pen/01a0e9e6-4c91-70a9-b205-dd7af73daea0](https://codepen.io/editor/GerardoCodesCardoso123/pen/01a0e9e6-4c91-70a9-b205-dd7af73daea0).

huyhuyhuy